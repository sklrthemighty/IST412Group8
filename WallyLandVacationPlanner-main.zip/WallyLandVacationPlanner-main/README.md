# WallyLandVacationPlanner

## Team 8
- Skyler Ames
- Keith Christensen
- Yanxi Wang

## Explanation
> The app's main features will involve buying tickets, scheduling activities receiving updates on park status and ordering food options that cater to different guest preferences while also offering useful insights, for park administrators. In terms of operations, the app should connect with the park systems, for ticketing, point of sale transactions, and managing attractions. Moreover, it should offer analytic tools to help park administrators allocate resources efficiently and enhance the overall effectiveness of the park experience.  
