/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ist.project412;

/**
 *
 * @author njthe
 */
public class Admin {
    private String adminId;

    public Admin(String adminId) {
        this.adminId = adminId;
    }

    public void viewStatistics(Statistics statistics) {
        System.out.println("Total Visitors: " + statistics.getTotalVisitors());
        System.out.println("Total Sales: " + statistics.getTotalSales());
    }
}
