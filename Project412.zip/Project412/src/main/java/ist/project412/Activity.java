/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ist.project412;

/**
 *
 * @author njthe
 */
import java.util.ArrayList;
import java.util.List;

public class Activity {
    private String name;
    private String timeSlot;
    private boolean isScheduled;

    public Activity(String name, String timeSlot) {
        this.name = name;
        this.timeSlot = timeSlot;
        this.isScheduled = false;
    }

    // Getters and Setters
    public String getName() { return name; }
    public String getTimeSlot() { return timeSlot; }
    public boolean isScheduled() { return isScheduled; }

    public void scheduleActivity() { this.isScheduled = true; }
    public void cancelActivity() { this.isScheduled = false; }
}

