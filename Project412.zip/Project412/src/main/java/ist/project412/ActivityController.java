/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ist.project412;

/**
 *
 * @author njthe
 */
public class ActivityController {
    private ActivityManager activityManager;

    public ActivityController() {
        activityManager = new ActivityManager();
    }

    public void scheduleActivity(Activity activity) {
        activity.scheduleActivity();
        activityManager.addActivity(activity);
    }

    public void cancelActivity(Activity activity) {
        activity.cancelActivity();
        activityManager.removeActivity(activity);
    }
}
