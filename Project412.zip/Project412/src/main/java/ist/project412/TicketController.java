/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ist.project412;

/**
 *
 * @author njthe
 */
public class TicketController {
    public Ticket purchaseTicket(int ticketId, double price) {
        Ticket ticket = new Ticket(ticketId, price);
        ticket.validateTicket();
        return ticket;
    }
}
