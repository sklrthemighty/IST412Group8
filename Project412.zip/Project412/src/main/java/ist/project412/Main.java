/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ist.project412;

/**
 *
 * @author njthe
 */
 public class Main { 
     public static void main(String[] args) { 
         User user = new User("testUser", "password123", "test@example.com"); 
         UserController userController = new UserController(user); 
         
         if (userController.login("testUser", "password123")) { 
             System.out.println("Login Successful!"); 
         } else { 
             System.out.println("Login Failed."); 
         } 
         
         TicketController ticketController = new TicketController(); 
         Ticket ticket = ticketController.purchaseTicket(1, 99.99); 
         System.out.println("Ticket ID: " + ticket.getTicketId() + ", Price: " + ticket.getPrice()); 
     } 
 }
