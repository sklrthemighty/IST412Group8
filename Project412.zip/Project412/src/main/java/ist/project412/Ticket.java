/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ist.project412;

/**
 *
 * @author njthe
 */
public class Ticket {
    private int ticketId;
    private double price;
    private boolean isValid;

    public Ticket(int ticketId, double price) {
        this.ticketId = ticketId;
        this.price = price;
        this.isValid = false;
    }

    // Getters and Setters
    public int getTicketId() { return ticketId; }
    public double getPrice() { return price; }
    public boolean isValid() { return isValid; }

    public void validateTicket() { this.isValid = true; }
}
