/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ist.project412;

/**
 *
 * @author njthe
 */
public class Statistics {
    private int totalVisitors;
    private int totalSales;

    public Statistics() {
        this.totalVisitors = 0;
        this.totalSales = 0;
    }

    public void incrementVisitors() { totalVisitors++; }
    public void addSales(int amount) { totalSales += amount; }

    public int getTotalVisitors() { return totalVisitors; }
    public int getTotalSales() { return totalSales; }
}

